═══════════════════════════════════════════════════════════════
        SNE RADAR - Guia de Instalação e Uso
═══════════════════════════════════════════════════════════════

⚠️  AVISO IMPORTANTE DE PROPRIEDADE INTELECTUAL

Este software é fornecido para TESTE e AVALIAÇÃO APENAS.
Leia o EULA.txt antes de usar.

───────────────────────────────────────────────────────────────

📦 INSTALAÇÃO (Windows)

1. Extraia este arquivo ZIP

2. Leia o EULA.txt e aceite os termos

3. Execute o SNE_RADAR.exe:
   - Duplo clique no arquivo SNE_RADAR.exe
   - OU clique com botão direito > Executar como administrador

4. Na primeira execução, o Windows Defender pode bloquear:
   - Clique em "Mais informações"
   - Clique em "Executar mesmo assim"

───────────────────────────────────────────────────────────────

⚠️  RESTRIÇÕES DE USO

Este é um build de TESTE. Você NÃO pode:

❌ Compartilhar com outras pessoas
❌ Fazer engenharia reversa
❌ Usar comercialmente sem autorização
❌ Redistribuir o software

───────────────────────────────────────────────────────────────

Obrigado por testar o SNE RADAR!

═══════════════════════════════════════════════════════════════
                    © 2025 SNE RADAR
═══════════════════════════════════════════════════════════════
